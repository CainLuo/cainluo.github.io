/// Copyright (c) 2022 Kodeco Inc.
///
/// Permission is hereby granted, free of charge, to any person obtaining a copy
/// of this software and associated documentation files (the "Software"), to deal
/// in the Software without restriction, including without limitation the rights
/// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
/// copies of the Software, and to permit persons to whom the Software is
/// furnished to do so, subject to the following conditions:
///
/// The above copyright notice and this permission notice shall be included in
/// all copies or substantial portions of the Software.
///
/// Notwithstanding the foregoing, you may not use, copy, modify, merge, publish,
/// distribute, sublicense, create a derivative work, and/or sell copies of the
/// Software in any work that is designed, intended, or marketed for pedagogical or
/// instructional purposes related to programming, coding, application development,
/// or information technology.  Permission for such use, copying, modification,
/// merger, publication, distribution, sublicensing, creation of derivative works,
/// or sale is expressly withheld.
///
/// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
/// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
/// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
/// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
/// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
/// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
/// THE SOFTWARE.

import SwiftUI
import Charts

struct WeeklyTemperatureChart: View {
  var measurements: [DayInfo]
  var month: Int
  let colorForAverageTemperature: Color = .red
  let colorForLowestTemperature: Color = .blue.opacity(0.3)
  let colorForHighestTemperature: Color = .yellow.opacity(0.4)

  var body: some View {
    weeklyTemperatureView
  }

  var weeklyTemperatureView: some View {
    return VStack {
      Picker("Chart Type", selection: $chartType.animation(.easeInOut)) {
        Text("Bar").tag(TemperatureChartType.bar)
        Text("Line").tag(TemperatureChartType.line)
      }
      .pickerStyle(.segmented)

      List(1..<6) { week in
        VStack {
          Chart(measurementsBy(month: month, week: week)) { dayInfo in
            switch chartType {
            case .bar:
              BarMark(
                x: .value("Day", dayInfo.date),
                yStart: .value("Low", dayInfo.temp(type: .low)),
                yEnd: .value("High", dayInfo.temp(type: .high)),
                width: 10
              )
              .foregroundStyle(
                Gradient(
                  colors: [
                    colorForHighestTemperature,
                    colorForLowestTemperature
                  ]
                )
              )
              RectangleMark(
                x: .value("Day", dayInfo.date),
                y: .value("Temperature", dayInfo.temp(type: .avg)),
                width: 5,
                height: 5
              )
              .foregroundStyle(colorForAverageTemperature)
            case .line:
              LineMark(
                x: .value("Day", dayInfo.date),
                y: .value("Temperature", dayInfo.temp(type: .avg))
              )
              .foregroundStyle(colorForAverageTemperature)
              .symbol(.circle)
              .interpolationMethod(.catmullRom)
              AreaMark(
                x: .value("Day", dayInfo.date),
                yStart: .value("Low", dayInfo.temp(type: .low)),
                yEnd: .value("High", dayInfo.temp(type: .high))
              )
              .foregroundStyle(
                Gradient(
                  colors: [
                    colorForHighestTemperature,
                    colorForLowestTemperature
                  ]
                )
              )
            }
          }
          .chartXAxis {
            AxisMarks(values: .stride(by: .day))
          }
          .chartYAxisLabel("ºF")
          .chartForegroundStyleScale([
            TemperatureTypes.avg.rawValue: colorForAverageTemperature,
            TemperatureTypes.low.rawValue: colorForLowestTemperature,
            TemperatureTypes.high.rawValue: colorForHighestTemperature
          ])
        }
        .frame(
          height: 200.0
        )
      }
      .listStyle(.plain)
    }
  }

  func measurementsByMonth(_ month: Int) -> [DayInfo] {
    return self.measurements
      .filter {
        Calendar.current.component(.month, from: $0.date) == month + 1
      }
  }

  func measurementsBy(month: Int, week: Int) -> [DayInfo] {
    return self.measurementsByMonth(month)
      .filter {
        let day = Calendar.current.component(.day, from: $0.date)
        if week == 1 {
          return day <= 7
        } else if week == 2 {
          return (day > 7 && day <= 14)
        } else if week == 3 {
          return (day > 14 && day <= 21)
        } else if week == 4 {
          return (day > 21 && day <= 28)
        } else {
          return day > 28
        }
      }
  }

  enum TemperatureChartType {
    case bar
    case line
  }

  @State var chartType: TemperatureChartType = .bar
}

struct WeeklyTemperatureChart_Previews: PreviewProvider {
  static var previews: some View {
    // swiftlint:disable force_unwrapping
    WeeklyTemperatureChart(
      measurements: WeatherInformation()!.stations[2].measurements, month: 1)
  }
}
